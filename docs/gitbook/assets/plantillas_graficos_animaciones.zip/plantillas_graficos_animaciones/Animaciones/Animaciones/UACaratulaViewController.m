//
//  UACaratulaViewController.m
//  Animaciones
//
//  Created by Miguel Angel Lozano on 19/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "UACaratulaViewController.h"

@implementation UACaratulaViewController


- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization

    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.vistaFrontal = [[UIImageView alloc] initWithImage: [UIImage imageNamed: @"frontal.jpg"]];
    self.vistaFrontal.frame = self.vistaCaratula.bounds;
    self.vistaFrontal.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.vistaReverso = [[UIImageView alloc] initWithImage: [UIImage imageNamed: @"reverso.jpg"]];
    self.vistaReverso.frame = self.vistaCaratula.bounds;
    self.vistaReverso.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.vistaCaratula addSubview: self.vistaFrontal];
}


- (void)viewDidUnload
{
    [self setVistaCaratula:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)botonZoomInPulsado:(id)sender {
    // TODO (d) Hacer una animación de un segundo que cambie el tamaño (bounds) de las vistas self.vistaFrontal y self.vistaReverso a (0,0,320,416). Lo haremos mediante las facilidades de UIView

}

- (IBAction)botonZoomOutPulsado:(id)sender {
    // TODO (d) Hacer una animación de un segundo que cambie el tamaño (bounds) de las vistas self.vistaFrontal y self.vistaReverso a (0,0,160,208). Lo haremos mediante las facilidades de UIView

}

- (IBAction)botonGirarPulsado:(id)sender {
    if(self.vistaFrontal.superview) {
        // TODO (c) Hacer transición de tipo giro a la izquierda de vistaFrontal a vistaReverso

    } else {
        // TODO (c) Hacer transición de tipo giro a la derecha de vistaReverso a vistaFrontal
        
    }
}

- (IBAction)botonCerrarPulsado:(id)sender {
    [self dismissModalViewControllerAnimated:YES];
}

@end
