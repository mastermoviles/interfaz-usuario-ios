//
//  UAViewController.h
//  Animaciones
//
//  Created by Miguel Angel Lozano on 09/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface UAViewController : UIViewController

@property (strong, nonatomic) CALayer *capaPortada;

- (IBAction)botonVenAquiPulsado:(UIButton *)sender;
- (IBAction)botonCaractulaPulsado:(id)sender;

@end
