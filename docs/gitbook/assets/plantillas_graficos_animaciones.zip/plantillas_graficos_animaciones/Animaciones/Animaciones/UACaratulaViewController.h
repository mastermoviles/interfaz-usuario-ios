//
//  UACaratulaViewController.h
//  Animaciones
//
//  Created by Miguel Angel Lozano on 19/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UACaratulaViewController : UIViewController

@property (strong, nonatomic) UIImageView *vistaFrontal;
@property (strong, nonatomic) UIImageView *vistaReverso;

@property (strong, nonatomic) IBOutlet UIView *vistaCaratula;
- (IBAction)botonZoomInPulsado:(id)sender;
- (IBAction)botonZoomOutPulsado:(id)sender;

- (IBAction)botonGirarPulsado:(id)sender;

- (IBAction)botonCerrarPulsado:(id)sender;
@end
