//
//  UAViewController.m
//  Animaciones
//
//  Created by Miguel Angel Lozano on 09/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "UAViewController.h"

#import "UACaratulaViewController.h"

@implementation UAViewController


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.capaPortada = [CALayer layer];
    self.capaPortada.position = self.view.center;
    self.capaPortada.bounds = CGRectMake(0, 0, 100, 100);
    
    // TODO (a) Configurar la capa con
    // 1. Radio de esquinas 10
    // 2. Grosor de borde 2
    // 3. Color de fondo blanco
    // 4. Color de borde gris

    self.capaPortada.contents = (id)[UIImage imageNamed:@"resplandor.jpg"].CGImage;
    self.capaPortada.contentsGravity = kCAGravityResizeAspect;
    
    [self.view.layer addSublayer: self.capaPortada];
}

- (void)viewDidUnload
{
    self.capaPortada = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}


- (IBAction)botonVenAquiPulsado:(UIButton *)sender {
    // TODO (b) Hacer que la capa con la imagen de la pelicula (self.capaPortada) se mueva a la posición que ocupa el botón pulsado (sender.center) de forma animada

}

- (IBAction)botonCaractulaPulsado:(id)sender {
    UACaratulaViewController *controller = [[UACaratulaViewController alloc] initWithNibName:@"UACaratulaView" bundle:nil];
    [self presentModalViewController:controller animated:YES];
}

@end
