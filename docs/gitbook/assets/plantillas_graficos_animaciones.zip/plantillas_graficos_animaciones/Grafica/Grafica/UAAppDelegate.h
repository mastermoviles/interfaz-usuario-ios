//
//  UAAppDelegate.h
//  Grafica
//
//  Created by Miguel Angel Lozano on 19/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UAViewController;

@interface UAAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UAViewController *viewController;

@end
