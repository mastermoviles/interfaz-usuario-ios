//
//  UAViewController.h
//  Grafica
//
//  Created by Miguel Angel Lozano on 19/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "S7GraphView.h"

@interface UAViewController : UIViewController<S7GraphViewDataSource>

@end
