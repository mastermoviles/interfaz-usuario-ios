//
//  UAViewController.m
//  Grafica
//
//  Created by Miguel Angel Lozano on 19/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "UAViewController.h"

@implementation UAViewController

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    S7GraphView *graphView = [[S7GraphView alloc] initWithFrame: CGRectMake(0, 0, 480, 300)];
    graphView.dataSource = self;
    [self.view addSubview: graphView];
    [self.view setFrame:CGRectMake(0, 0, 480, 300)];

    NSNumberFormatter *numberFormatter = [NSNumberFormatter new];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    [numberFormatter setMinimumFractionDigits:0];
    [numberFormatter setMaximumFractionDigits:0];
    
    graphView.yValuesFormatter = numberFormatter;
    
    NSDateFormatter *dateFormatter = [NSDateFormatter new];
    [dateFormatter setTimeStyle:NSDateFormatterNoStyle];
    [dateFormatter setDateStyle:NSDateFormatterShortStyle];
    
    graphView.xValuesFormatter = dateFormatter;
    
    graphView.backgroundColor = [UIColor blackColor];

    graphView.drawAxisX = YES;
    graphView.drawAxisY = YES;
    graphView.drawGridX = YES;
    graphView.drawGridY = YES;
    
    graphView.xValuesColor = [UIColor whiteColor];
    graphView.yValuesColor = [UIColor whiteColor];
    
    graphView.gridXColor = [UIColor whiteColor];
    graphView.gridYColor = [UIColor whiteColor];
    
    graphView.drawInfo = YES;
    graphView.info = @"Cuota de mercado";
    graphView.infoColor = [UIColor whiteColor];
    
    [graphView reloadData];    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft);
}

#pragma mark - Delegado de S7GraphView

- (NSUInteger)graphViewNumberOfPlots:(S7GraphView *)graphView {
    return 3;
}

- (NSArray *)graphViewXValues:(S7GraphView *)graphView {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeStyle:NSDateFormatterNoStyle];
    [dateFormatter setDateFormat: @"MM-yyyy"];
    
    return @[[dateFormatter dateFromString:@"01-2010"], 
             [dateFormatter dateFromString:@"07-2010"],
             [dateFormatter dateFromString:@"01-2011"],
             [dateFormatter dateFromString:@"07-2011"],
             [dateFormatter dateFromString:@"01-2012"]];
}

- (NSString *)graphView:(S7GraphView *)graphView legendForPlot:(NSUInteger)plotIndex {
    switch(plotIndex) {
        case 0:
            return @"iOS";
        case 1:
            return @"Android";
        case 2:
            return @"Windows Phone";
        default:
            return @"";
    }
}

- (NSArray *)graphView:(S7GraphView *)graphView yValuesForPlot:(NSUInteger)plotIndex {
    switch(plotIndex) {
        case 0:
            return @[@70,@50,@40,@35,@30];
        case 1:
            return @[@30,@50,@55,@58,@60];
        case 2:
            return @[@0,@0,@5,@7,@10];
        default:
            return nil;
    }
}

@end
